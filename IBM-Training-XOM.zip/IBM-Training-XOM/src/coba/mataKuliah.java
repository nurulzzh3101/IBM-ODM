package coba;

public class mataKuliah {
	int totalSKS;
	int sksDiambil;
	int sisa;
	int ipk;
	
	public int getTotalSKS() {
		return totalSKS;
	}
	public void setTotalSKS(int totalSKS) {
		this.totalSKS = totalSKS;
	}
	public int getSksDiambil() {
		return sksDiambil;
	}
	public void setSksDiambil(int sksDiambil) {
		this.sksDiambil = sksDiambil;
	}
	public int getSisa() {
		return sisa;
	}
	public void setSisa(int sisa) {
		this.sisa = sisa;
	}
	public int getIpk() {
		return ipk;
	}
	public void setIpk(int ipk) {
		this.ipk = ipk;
	}
	
	public void hitungSisa(int sksDiambil, int totalSKS) {
		this.sisa = totalSKS - sksDiambil;
	}
}
